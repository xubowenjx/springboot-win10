/**
 * 背景图片切换
 * 创意：宝通
 * 润色：Yuri2
 * */

 使用说明，将theme_switcher.html 作为子页
 比如放在桌面图标或者开始菜单中


 桌面图标的例子：
 <div class="shortcut win10-open-window" data-url="./plugins/theme_switcher/theme_switcher.html">
                 <i class="icon fa fa-fw fa-picture-o blue" ></i>
                 <div class="title">切换壁纸</div>
             </div>


 目录结构

 win10-ui
    -plugins
        -theme_switcher
            -css,js,html.....

