字符雨动态壁纸

* 原素材来源于网络

1.引入 character-rain.js
2.欣赏字符雨吧